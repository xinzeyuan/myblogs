package com.oppo.iot.smarthome.common.utils;

import com.oppo.asynchttpclient.core.HttpCallback;
import com.oppo.asynchttpclient.core.HttpClient;
import com.oppo.asynchttpclient.core.HttpClientBuilder;
import com.oppo.asynchttpclient.netty.NettyHttpClientBuilder;
import io.netty.handler.codec.http.DefaultHttpHeaders;
import io.netty.handler.codec.http.HttpHeaders;
import io.netty.handler.codec.http.HttpResponseStatus;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.CountDownLatch;

/**
 * @author 80119490
 * @Date 2018/10/16
 */
public class NettyAsyncHttpClient {
    private static final Logger LOGGER = LoggerFactory.getLogger(NettyAsyncHttpClient.class);

    private static  final ConcurrentMap<String,HttpClient> httpClientConcurrentMap = new ConcurrentHashMap<>();

    public static void main(String[] args) throws MalformedURLException {
        System.out.println(execute("https://www.oppo.com/cn","get",null,null,3000,5000));
    }

    public static byte[] execute(String url, String method, Map<String, String> header, byte[] body, Integer connectionTimeout, Integer readTimeOut){
        String host;
        String path;
        String query;
        int port;
        try {
            URL realUrl = new URL(url);
            host = realUrl.getHost();
            port = realUrl.getPort();
            path = realUrl.getPath();
            query = realUrl.getQuery();
        } catch (MalformedURLException e) {
            LOGGER.error("==============parse url host error=====================" + url);
            return null;
        }

        HttpClient httpClient = httpClientConcurrentMap.get(host);
        if(httpClient == null){
            HttpClientBuilder clientBuilder = new NettyHttpClientBuilder()
                    .connectionPoolSize(20140)
                    .connectPoolWaitQueueSize(512)
                    .connectTimeout(3000)
                    .readTimeout(5000)
                    .host(host);

            if(url.startsWith("https")) {
                httpClient = clientBuilder
                        .sniHostName(host)
                        .port(443)
                        .useHttps(true)
                        .build();
            }
            else {
                //无法解析端口,则使用默认80端口
                if(port < 0){
                    port = 80;
                }
                httpClient = clientBuilder
                        .port(port)
                        .useHttps(false)
                        .build();
            }

            httpClientConcurrentMap.putIfAbsent(host,httpClient);
        }

        final byte[][] data = {null};

        //设置header
        HttpHeaders httpHeaders = new DefaultHttpHeaders();
        if(header != null){
            for (Map.Entry<String, String> entry : header.entrySet()){
                httpHeaders.set(entry.getKey(),entry.getValue());
            }
        }

        //更新参数
        httpClient.updateParameter(10240,1024,connectionTimeout,0,readTimeOut);

        CountDownLatch latch = new CountDownLatch(1);

        String uri = path;
        if(StringUtils.isNotBlank(query)){
            uri = uri + "?" +query;
        }
        try {
            httpClient.sendRequest(uri, method.toUpperCase(), httpHeaders, body, new HttpCallback() {
                @Override
                public void onWriteNetworkSuccess() {

                }

                @Override
                public void onError(Throwable e) {
                    latch.countDown();
                    LOGGER.error("================execute http request error==================================url:" + url,e.getCause());
                }

                @Override
                public void onResponse(int statusCode, HttpHeaders headers, byte[] body) {
                    latch.countDown();
                    if(statusCode != HttpResponseStatus.OK.code()){
                        LOGGER.error("=====================response code error============================url:" + url + "=============code:" + statusCode);
                    }
                    else {
                        data[0] = body;
                    }
                }
            });
        } catch (Exception e) {
            LOGGER.error("=================execute http client failed============================" + url,e);
        }

        //等待回调完成
        try {
            latch.await();
        } catch (InterruptedException e) {
            LOGGER.error("================http count down latch error============================",e);
            return null;
        }

        return data[0];
    }
}
