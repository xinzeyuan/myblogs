package com.oppo.iot.smarthome.common.utils;

import okhttp3.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * @author 80119490
 */
public class SmartHomeOkHttpClient {
    private static final Logger LOGGER = LoggerFactory.getLogger(HttpUtils.class);
    private static final Integer DEFAULT_CONNECTION_TIMEOUT = 10;
    private static final Integer DEFAULT_READ_TIMEOUT = 30;

    private static final OkHttpClient okHttpClient = new OkHttpClient();

    static {
        X509TrustManager trustManager = new X509TrustManager() {
            @Override
            public void checkClientTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
            }

            @Override
            public void checkServerTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
            }

            @Override
            public X509Certificate[] getAcceptedIssuers() {
                return new X509Certificate[0];
            }
        };
        SSLContext sslContext = null;
        try{
            sslContext  = SSLContext.getInstance("SSL");
            sslContext.init(null,new TrustManager[]{trustManager},new SecureRandom());
        }
        catch (Exception ex){
            LOGGER.error("build http ssl context error",ex);
        }
        HostnameVerifier hostnameVerifier = (hostname, session) -> true;

        OkHttpClient.Builder okHttpBuilder =  okHttpClient.newBuilder()
                .hostnameVerifier(hostnameVerifier)
                .connectTimeout(DEFAULT_CONNECTION_TIMEOUT,TimeUnit.SECONDS)
                .readTimeout(DEFAULT_READ_TIMEOUT,TimeUnit.SECONDS)
                .followRedirects(false)
                .followSslRedirects(false);

        if(sslContext != null) {
            okHttpBuilder.sslSocketFactory(sslContext.getSocketFactory(), trustManager);
        }
    }

    public static byte[] executeByOkHttpClient(String url, String method, Map<String, String> header, byte[] body, Integer connectionTimeout, Integer readTimeOut) {
        Response response = null;

        try {
            if(!url.startsWith("http")){
                url = "http://"+url;
            }
            Request.Builder requestBuilder = new Request.Builder().url(url);

            //连接超时
            if(connectionTimeout != null){
                okHttpClient.newBuilder().connectTimeout(connectionTimeout,TimeUnit.MILLISECONDS);
            }

            //读取超时
            if(readTimeOut != null){
                okHttpClient.newBuilder().readTimeout(readTimeOut,TimeUnit.MILLISECONDS);
            }

            if(header != null){
                //维持连接
                header.putIfAbsent("Connection", "keep-alive");

                //填充header
                for(Map.Entry<String, String> entry : header.entrySet()){
                    requestBuilder.addHeader(entry.getKey(),entry.getValue());
                }
            }

            //传输body
            if(body != null){
                RequestBody requestBody = RequestBody.create(MediaType.parse("application/json; charset=utf-8"),body);
                requestBuilder.method(method,requestBody);
            }

            response = okHttpClient.newCall(requestBuilder.build()).execute();

            if(response != null){
                if(response.isSuccessful()) {
                    return response.body().bytes();
                }
                else {
                    LOGGER.warn("=============response info================",response.code(),response.message(),response.body() != null ? response.body().string():"");
                }
            }

            return null;
        } catch (Exception e) {
            LOGGER.error("fetch http error,url:{}",url,e);
        }
        finally {
            if(response != null){
                response.close();
            }
        }
        return null;
    }
}