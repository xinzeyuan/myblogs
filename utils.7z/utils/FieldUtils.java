/*
 * Copyright (c) 2019 OPPO. All rights reserved.
 */
package com.oppo.iot.smarthome.common.utils;

import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.*;
import java.util.function.Function;

import static java.util.stream.Collectors.toMap;

/**
 * <p>
 * Description:
 * </p>
 *
 * @author ouyangyiding
 * @version 1.0
 * @Date 2019/4/24
 */
public class FieldUtils {
    private static final Logger log = LoggerFactory.getLogger(FieldUtils.class);

    /**
     * 比较一个Collection中某项属性是否有重复的
     * @param list
     * @param function
     * @param <T>
     * @param <R>
     * @return
     */
    public static <T, R> boolean isRepeatField(Collection<T> list, Function<T, R> function) {
        if (CollectionUtils.isEmpty(list)) {
            return false;
        }
        if (function == null) {
            return false;
        }
        return list.stream()
                .map(function)
                .collect(toMap(e -> e, e -> 1, Integer::sum))
                .values().stream()
                .anyMatch(val -> val > 1);
    }

    /**
     * 对于2个相同类（不方便重写equal）的对象，对该类的特定属性集合的比较
     * @param a
     * @param b
     * @param fieldNames
     * @param <T>
     * @return true-指定属性完全相同
     * @throws Exception
     */
    public static <T> boolean isFieldsEqual(T a, T b, Set<String> fieldNames) {
        if (a == b) {
            return true;
        }
        // 两个对象任一为空
        if (a == null || b == null) {
            log.debug("a & b == null");
            return false;
        }
        if (!a.getClass().equals(b.getClass())) {
            log.debug("a is not same class of b");
            return false;
        }
        Class<?> aClass = a.getClass();
        Object aFieldVal = null;
        Object bFieldVal = null;
        for (Field field : aClass.getDeclaredFields()) {
            // fieldNames == null 意味着全部字段检查
            if (fieldNames != null && !fieldNames.contains(field.getName())) {
                continue;
            }
            try {
                PropertyDescriptor pd = new PropertyDescriptor(field.getName(), aClass);
                Method readMethod = pd.getReadMethod();
                aFieldVal = readMethod.invoke(a);
                bFieldVal = readMethod.invoke(b);
                if (!Objects.equals(aFieldVal, bFieldVal)) {
                    log.debug("not equal, field:{}, aVal:{}, bVal:{}",
                            field.getName(), aFieldVal, bFieldVal);
                    return false;
                }
            } catch (Exception e) {
                log.debug("class={} field={} isFieldsEqual: aFieldVal={}, bFieldVal={}", new Object[]{aClass.getName(),
                        field.getName(), aFieldVal, bFieldVal});
                log.error("isFieldsEqual ERR: " + e.getMessage());
            }
        }
        return true;
    }



    /**
     * 相同的Class，从fromObj向toObj填充指定field
     * @param toObj
     * @param fromObj
     * @param fieldNames
     * @param <T>
     */
    public static <T> void fillPointFields(T toObj, T fromObj, Set<String> fieldNames) {
        fieldNames = checkBeforeFill(toObj, fromObj, fieldNames);
        Class<?> aClass = toObj.getClass();
        for (Field field : aClass.getDeclaredFields()) {
            if (!fieldNames.contains(field.getName())) {
                continue;
            }
            fill(aClass, field, toObj, fromObj);
        }
    }

    public static <T> void fillFieldsExceptPointField(T toObj, T fromObj, Set<String> fieldNames) {
        fieldNames = checkBeforeFill(toObj, fromObj, fieldNames);
        Class<?> aClass = toObj.getClass();
        for (Field field : aClass.getDeclaredFields()) {
            if (fieldNames.contains(field.getName())) {
                continue;
            }
            fill(aClass, field, toObj, fromObj);
        }
    }

    private static <T> Set<String> checkBeforeFill(T toObj, T fromObj, Set<String> fieldNames) {
        if (!toObj.getClass().equals(fromObj.getClass())) {
            log.error("not same class, oldObj={}, newObj={}", toObj.getClass().getName(), fromObj.getClass().getName());
            throw new IllegalArgumentException("oldObj is not the same class of newObj!");
        }
        if (fieldNames == null) {
            fieldNames = new HashSet<>();
        }
        return fieldNames;
    }


    /**
     * 将newObj值填入toObj的Field中
     * @param aClass
     * @param field
     * @param toObj
     * @param fromObj
     * @param <T>
     */
    private static <T> void fill(Class<?> aClass, Field field, T toObj, T fromObj) {
        Object oldVal = null;
        Object newVal = null;
        try {
            PropertyDescriptor pd = new PropertyDescriptor(field.getName(), aClass);
            Method readMethod = pd.getReadMethod();
            oldVal = readMethod.invoke(toObj);
            newVal = readMethod.invoke(fromObj);
            Method writeMethod = pd.getWriteMethod();
            writeMethod.invoke(toObj, newVal);
        } catch (Exception e) {
            log.error("fill field, err:{} class={} field={} isFieldsEqual: oldVal={}, newVal={}",
                    new Object[]{e.getMessage(), aClass.getName(), field.getName(), oldVal, newVal});
        }
    }

    /**
     * 判断list中是否有匹配id的项目
     * @param <T>
     * @param list
     * @param function
     * @param id
     * @return 具体位置， -1为找不到
     */
    public static  <T, R> int findIndexOfSameId(List<T> list, Function<T, R> function, R id) {
        if (CollectionUtils.isEmpty(list)) {
            return -1;
        }
        int[] index = {-1};
        boolean exist = list.stream()
                .peek(e -> index[0]++)
                .anyMatch(e -> {
                    R idNew = function.apply(e);
                    return idNew != null && id.equals(idNew);
                });
        return exist ? index[0] : -1;
    }
}
