package com.oppo.iot.smarthome.common.utils;

import com.oppo.iot.redis.PipelineCluster;
import com.oppo.iot.smarthome.common.annotation.DoLog;
import com.oppo.iot.smarthome.common.cache.RedisCacheService;
import com.oppo.trace.springaop.WithTrace;
import lombok.extern.slf4j.Slf4j;

/**
 * 分布式锁
 *
 * @author 80249849
 * @date 2019-11-25
 */
@Slf4j
@WithTrace(recordMethodArgs = true)
public class DistributedLockUtils {
    private final static DistributedLockUtils REDIS_LOCK = new DistributedLockUtils(LockType.REDIS);
    // private final static DistributedLockUtils ZK_LOCK = new DistributedLockUtils(LockType.ZOOKEEPER);

    private final LockType type;

    private DistributedLockUtils(LockType type) {
        this.type = type;
    }

    public static DistributedLockUtils of(LockType type) {
        // if (type == LockType.ZOOKEEPER) {
        //     return ZK_LOCK;
        // }

        if (type == LockType.REDIS) {
            return REDIS_LOCK;
        }
        throw new IllegalStateException();
    }

    /**
     * 尝试获取分布式锁。
     * set value 是为了自己的锁自己解且清楚是谁加的锁。
     * setex 是为了防止客户端长时间不解锁（等多种原因）导致死锁。
     * setnx 保证独占。
     *
     * @param redis      RedisCacheService 实例
     * @param lockKey    锁
     * @param lockVal    唯一身份
     * @param expireTime 过期时间，单位秒
     * @return 是否成功获取
     */
    @DoLog
    public boolean tryLock(
            RedisCacheService redis,
            String lockKey,
            String lockVal,
            int expireTime
    ) {

        // if (type == LockType.ZOOKEEPER) {
        //
        // }
        if (type == LockType.REDIS) {
            return redis.setNxObjectValue(lockKey, lockVal, expireTime);
        }
        throw new IllegalStateException();
    }

    /**
     * 释放分布式锁，通过 lua 脚本实现原子性，判断是否是自己加的锁，如果不是则不能解锁，保证锁安全。
     *
     * @param redis        RedisCacheService 实例
     * @param redisCluster PipelineCluster 实例
     * @param lockKey      锁
     * @param lockVal      唯一身份
     * @return 是否成功释放
     */
    public boolean tryRelease(
            RedisCacheService redis,
            PipelineCluster redisCluster,
            String lockKey,
            String lockVal
    ) {

        // if (type == LockType.ZOOKEEPER) {
        //
        // }

        if (type == LockType.REDIS) {
            String script = "if redis.call('get', KEYS[1]) == ARGV[1] then return redis.call('del', KEYS[1]) else return 0 end";
            Object eval = redis.eval(script, redisCluster, lockKey, lockVal);
            log.debug("redis unlock, eval result ==> {}", eval);
            return eval != null && !LOCK_VAL_NO_EXIST.equals(eval);
        }
        throw new IllegalStateException();
    }

    private final static Long LOCK_VAL_NO_EXIST = 0L;

    public static DistributedLockUtils ofDefault() {
        return REDIS_LOCK;
    }

    public enum LockType {
        REDIS
        // ZOOKEEPER
    }
}
