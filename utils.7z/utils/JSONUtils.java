package com.oppo.iot.smarthome.common.utils;


import com.google.gson.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @author 80119490
 * @date 2020-06-30
 */
public class JSONUtils {

    private static final Logger LOGGER = LoggerFactory.getLogger(JSONUtils.class);

    private static final Gson gson = new GsonBuilder().setDateFormat(DateFormat.LONG)
            .serializeNulls()
            .registerTypeAdapter(Date.class, (JsonDeserializer<Date>) (jsonElement, type, context) -> new Date(jsonElement.getAsJsonPrimitive().getAsLong()))
            .registerTypeAdapter(Date.class, (JsonSerializer<Date>) (src, typeOfSrc, context) -> src == null ? null : new JsonPrimitive(src.getTime()))
            .create();

    public static String toJSONString(Object src) {
        return gson.toJson(src);
    }

    public static String toJSONPrettyString(Object src) {
        return gson.newBuilder().setPrettyPrinting().create().toJson(src);
    }

    public static <T> T parseObject(String objStr,Class<T>tClass){
        return gson.fromJson(objStr,tClass);
    }

    public static <T> T parseObject(byte[] obj,Class<T>tClass){
        if(null == obj){
            return null;
        }
        return gson.fromJson(new String(obj, StandardCharsets.UTF_8),tClass);
    }

    public static JsonObject parseObject(String objStr){
        if(null == objStr){
            return null;
        }
        return gson.toJsonTree(gson.fromJson(objStr, Map.class)).getAsJsonObject();
    }

    public static <T> List<T> parseArray(String objStr,Class<T>tClass){
        ListParameterizedType listParameterizedType = new ListParameterizedType(tClass);
        List<T> list = gson.fromJson(objStr, listParameterizedType);
        if (null == list)
            return null;
        return list;
    }

    public static <T> List<T> objConvert(List fromValue, Class<T> toValueType) {
        String json = gson.toJson(fromValue);
        List<T> list = parseArray(json, toValueType);
        return list;
    }

    public static <T> T objConvert(Object fromValue, Class<T> toValueType) {
        String tmp = gson.toJson(fromValue);
        T result = gson.fromJson(tmp,toValueType);
        return result;
    }

    public static byte[] toJSONBytes(Object obj) {
        return gson.toJson(obj).getBytes(StandardCharsets.UTF_8);
    }

    private static class ListParameterizedType implements ParameterizedType {
        private Type type;

        private ListParameterizedType(Type type) {
            this.type = type;
        }

        @Override
        public Type[] getActualTypeArguments() {
            return new Type[] {type};
        }

        @Override
        public Type getRawType() {
            return ArrayList.class;
        }

        @Override
        public Type getOwnerType() {
            return null;
        }
    }
}
