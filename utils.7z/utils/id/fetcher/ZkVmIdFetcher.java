package com.oppo.iot.smarthome.common.utils.id.fetcher;

/**
 * @author 80249849
 * @date 2019-03-27
 */
@Deprecated
public class ZkVmIdFetcher
        // extends AbstractVmIdFetcher
{
    // public static final AbstractVmIdFetcher SINGLETON_HOLDER = new ZkVmIdFetcher();
    //
    // private static final Logger LOGGER = LoggerFactory.getLogger(ZkVmIdFetcher.class);
    //
    // private final String nodeName = "instance";
    // private final String zkUrls;
    // private final String nodePath;
    //
    // private ZkVmIdFetcher() {
    //     zkUrls = PROP.getProperty(IdGenConstants.ZK_URLS_KEY);
    //     String path = PROP.getProperty(IdGenConstants.NODE_PATH_KEY);
    //     nodePath = path.concat(path.endsWith("/") ? "" : "/")
    //             .concat(APP_ID);
    // }
    //
    // @Override
    // public int fetch() {
    //     check();
    //     ZkClient zkClient = getZkClient();
    //     return execInsertion(zkClient);
    // }
    //
    // private int execInsertion(ZkClient zkClient) {
    //     int id;
    //     try {
    //         if (!zkClient.exists(nodePath)) {
    //             zkClient.createPersistent(nodePath, true);
    //         }
    //         id = extract(zkClient.createEphemeralSequential(
    //                 nodePath.concat("/")
    //                         .concat(nodeName),
    //                 null));
    //     } catch (Exception e) {
    //         LOGGER.error("can not get connection, " + getConnMsg());
    //         id = IdGenConstants.FETCHER_ERROR_CODE;
    //     } finally {
    //         try {
    //             zkClient.close();
    //         } catch (Exception ignored) {
    //         }
    //     }
    //     return id;
    // }
    //
    // private int extract(String fullNodeName) {
    //     return Integer.parseInt(
    //             fullNodeName.substring(
    //                     fullNodeName.lastIndexOf(nodeName)
    //                             + nodeName.length()));
    // }
    //
    // private ZkClient getZkClient() {
    //     return new ZkClient(zkUrls,
    //             Integer.valueOf(PROP.getProperty(IdGenConstants.ZK_CONNECTION_TIMEOUT_KEY)));
    // }
    //
    // private void check() {
    //     if (!StringUtils.isNoneEmpty(zkUrls, nodePath)) {
    //         throw new ConfigNotFoundException("config not found, " + getConnMsg());
    //     }
    // }
    //
    // private String getConnMsg() {
    //     return String.format(
    //             "zkUrls=\"%s\", path=\"%s\"",
    //             zkUrls, nodePath);
    // }
}
