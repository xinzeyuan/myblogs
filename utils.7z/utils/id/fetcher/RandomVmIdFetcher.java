package com.oppo.iot.smarthome.common.utils.id.fetcher;

/**
 * @author 80249849
 * @date 2019-03-27
 */
@Deprecated
public class RandomVmIdFetcher
        // extends AbstractVmIdFetcher
{
    // public static final AbstractVmIdFetcher SINGLETON_HOLDER = new RandomVmIdFetcher();
    //
    // private RandomVmIdFetcher() {
    // }
    //
    // @Override
    //
    // public int fetch() {
    //     return RandomUtils.nextInt(0, Integer.MAX_VALUE);
    // }
}
