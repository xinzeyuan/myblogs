package com.oppo.iot.smarthome.common.utils.id.fetcher;

import com.oppo.iot.smarthome.common.utils.id.AbstractVmIdFetcher;
import com.oppo.iot.smarthome.common.utils.id.IdGenConstants;
import com.oppo.iot.smarthome.common.utils.id.exception.ConfigNotFoundException;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.*;

/**
 * @author 80249849
 * @date 2019-03-27
 */
public class DbVmIdFetcher extends AbstractVmIdFetcher {
    public static final AbstractVmIdFetcher SINGLETON_HOLDER = new DbVmIdFetcher();
    private static final Logger LOGGER = LoggerFactory.getLogger(DbVmIdFetcher.class);

    private final String url;
    private final String driver;
    private final String username;
    private final String password;

    private DbVmIdFetcher() {
        super();
        url = PROP.getProperty(IdGenConstants.DB_URL_CONFIG_KEY);
        driver = PROP.getProperty(IdGenConstants.DB_DRIVER_CONFIG_KEY);
        username = PROP.getProperty(IdGenConstants.DB_USERNAME_CONFIG_KEY);
        password = PROP.getProperty(IdGenConstants.DB_PASSWORD_CONFIG_KEY);
    }


    @Override
    public int fetch() {
        check();
        Connection conn = getConn();
        return execInsertion(conn);
    }

    private int execInsertion(Connection conn) {
        String sql = "INSERT INTO vm_id_increment(biz) VALUES(?)";
        PreparedStatement ps = null;
        ResultSet rs = null;
        int success;
        int primaryKey;
        try {
            ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, APP_ID);
            success = ps.executeUpdate();
            if (success > 0) {
                rs = ps.getGeneratedKeys();
                if (rs == null) {
                    String msg = "can not get primary key.";
                    LOGGER.error(msg);
                    return IdGenConstants.FETCHER_ERROR_CODE;
                }
                rs.next();
                primaryKey = rs.getInt(1);
            } else {
                String msg = "failed to insert.";
                LOGGER.error(msg);
                primaryKey = IdGenConstants.FETCHER_ERROR_CODE;
            }
        } catch (Exception e) {
            primaryKey = IdGenConstants.FETCHER_ERROR_CODE;
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (Exception e) {
                    LOGGER.warn("error occurred when close ResultSet.");
                }
            }
            if (ps != null) {
                try {
                    ps.close();
                } catch (Exception e) {
                    LOGGER.warn("error occurred when close PreparedStatement.");
                }
            }
            if (conn != null) {
                try {
                    conn.close();
                } catch (Exception e) {
                    LOGGER.warn("error occurred when close Connection.");
                }
            }
        }
        return primaryKey;
    }

    private Connection getConn() {
        Connection conn = null;
        try {
            Class.forName(driver);
            conn = DriverManager.getConnection(url, username, password);
            int i = 3;
            while (conn == null && i > 0) {
                try {
                    Thread.sleep(1000);
                    conn = DriverManager.getConnection(url, username, password);
                } catch (InterruptedException ignored) {
                }
                --i;
            }
        } catch (Exception e) {
            LOGGER.error(String.format("can not get connection, %s", getConnMsg()), e);
        }
        if (conn == null) {
            throw new RuntimeException("can not get db connection.");
        }
        return conn;
    }

    private void check() {
        if (!StringUtils.isNoneEmpty(url, driver, username, password)) {
            throw new ConfigNotFoundException("config not found, " + getConnMsg());
        }
    }

    private String getConnMsg() {
        return String.format(
                "url=\"%s\", username=\"%s\", password=\"%s\"",
                url, username, password);
    }
}
