package com.oppo.iot.smarthome.common.utils.id;

import com.oppo.basic.heracles.client.HeraclesBootstrap;
import com.oppo.basic.heracles.client.core.store.KVStore;
import com.oppo.iot.smarthome.common.utils.id.exception.GeneratorException;
import com.oppo.iot.smarthome.common.utils.id.fetcher.DbVmIdFetcher;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigInteger;

/**
 * @author 80249849
 * @date 2019-03-26
 */
public class IdUtils {
    private static final Logger LOGGER = LoggerFactory.getLogger(IdUtils.class);
    public static final IdUtils SINGLETON_HOLDER = new IdUtils();

    /* 2019-03-26 00:00:00:000 */
    private final long twepoch = 1553529600000L;

    private final int sequenceIdBits = 9;
    private final int vmIdBits = 8;
    private final int zoneIdBits = 5;

    private final int vmIdShift = sequenceIdBits;
    private final int zoneIdShift = sequenceIdBits + vmIdBits;
    private final int timeShift = sequenceIdBits + vmIdBits + zoneIdBits;

    private final long sequenceMask = 0b111111111;
    private final long vmIdMask = 0b11111111;
    private final long zoneIdMask = 0b11111;

    private long zoneId;
    private long vmId;
    private long lastTimeStamp;
    private long seqInMill;

    private IdUtils() {
        init();
    }

    /**
     * 1位固定0 + 41位毫秒数 + 5位机房号 + 8位机器序号 + 9位毫秒内自增号 = 64 位 long
     * 从 twepoch 开始, 可用 69 年, 1 毫秒内理论上可以产生 512 个 ID.
     */
    public synchronized long gen() {
        long timestamp = getCurrentTimestamp();
        long last = getLastTimestamp();
        // 校验时钟回拨
        long ret = checkBackwards(timestamp, last);
        if (ret != 0L) {
            timestamp = ret;
        }
        // 校验毫秒内递增
        timestamp = fillSeq(timestamp, last);
        setLastTimeStamp(timestamp);
        return cal(timestamp);
    }

    // =========================== private methods ===========================

    private long fillSeq(long timestamp, long last) {
        if (timestamp == last) {
            seqInMill = (seqInMill + 1) & sequenceMask;
            // 毫秒内溢出
            if (seqInMill == 0) {
                timestamp = tillNextMill(last);
            }
        } else {
            seqInMill = 0L;
        }
        return timestamp;
    }

    private long cal(long timestamp) {
        return seqInMill | vmId << vmIdShift
                | zoneId << zoneIdShift
                | (timestamp - twepoch << timeShift);
    }

    private void init() {
        initZoneId();
        initVmId();
    }

    private void initZoneId() {
        String idc;
        HeraclesBootstrap.getInstance().init("*");
        if ("dev".equals(KVStore.getStringKey("env"))) {
            LOGGER.info("===============================================================\n" +
                    "===============================================================\n" +
                    "================    ID生成器采用【本地开发模式】   ================\n" +
                    "===============================================================\n" +
                    "===============================================================");
            idc = "LOCAL-DEVELOP-IDCCODE";
        } else {
            LOGGER.info("===============================================================\n" +
                    "===============================================================\n" +
                    "================  ID生成器采用【测试/生产环境模式】 ================\n" +
                    "===============================================================\n" +
                    "===============================================================");
            idc = System.getenv(IdGenConstants.IDC_KEY);
        }
        if (idc == null) {
            LOGGER.error("can not read system environment \"{}\".", IdGenConstants.IDC_KEY);
            System.exit(1);
            return;
        }
        char[] dict = IdGenConstants.DICT;
        int dictLen = dict.length;
        char[] idcCharArr = idc.toCharArray();
        int len = idcCharArr.length;
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < len; i++) {
            for (int j = 0; j < dictLen; j++) {
                if (dict[j] == idcCharArr[i]) {
                    sb.append(j < 10 ? "0" + j : j);
                    break;
                }
            }
        }
        zoneId = new BigInteger(sb.toString()).and(BigInteger.valueOf(Long.MAX_VALUE)).longValue() & zoneIdMask;
    }

    private void initVmId() {
        AbstractVmIdFetcher fetcher = DbVmIdFetcher.SINGLETON_HOLDER;
        int fetched = fetcher.fetch();
        if (fetched == IdGenConstants.FETCHER_ERROR_CODE) {
            LOGGER.error("can not fetch vm id from {}.", fetcher.getClass().getName());
            System.exit(1);
            return;
        }
        vmId = fetched & vmIdMask;
    }

    private long getCurrentTimestamp() {
        return System.currentTimeMillis();
    }

    private long getLastTimestamp() {
        return lastTimeStamp;
    }

    private void setLastTimeStamp(long lastTimeStamp) {
        this.lastTimeStamp = lastTimeStamp;
    }

    private long checkBackwards(long now, long last) {
        // 发生回拨
        if (last > now) {
            // 回拨不超过 5 毫秒, 尝试等待
            if (last - now < 5) {
                LOGGER.warn("try to suspend for {}ms due to clock backward(NTP).", (last - now) << 1);
                try {
                    Thread.sleep((last - now) << 1);
                } catch (InterruptedException e) {
                    LOGGER.error("thread been interrupted, threadName={}", Thread.currentThread().getName());
                    throw new GeneratorException("thread been interrupted.");
                }
                long newCur = getCurrentTimestamp();
                if (last > newCur) {
                    // 再次发生回拨
                    alarm("too many times clock backward found(NTP).");
                } else {
                    return newCur;
                }
            } else {
                // 大幅回拨
                alarm("clock backward too long(NTP).");
            }
        }
        return 0L;
    }

    /**
     * 说明：这里返回一个 UUID 比较好，至少保证服务可用，但是为了新表能用上 bigint，所以这里做简单报错处理，影响不大
     */
    private void alarm(String msg) {
        // 日志告警
        LOGGER.error("IdUtils alarm ==> " + msg);
        throw new GeneratorException(msg);
    }

    private long tillNextMill(long last) {
        long current = getCurrentTimestamp();
        while (current <= last) {
            // TODO 考虑非常极端的情况：毫秒内溢出时又发生回拨 => 后续完善
            current = getCurrentTimestamp();
        }
        return current;
    }

}
