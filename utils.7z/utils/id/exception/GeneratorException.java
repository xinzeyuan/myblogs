package com.oppo.iot.smarthome.common.utils.id.exception;

/**
 * @author 80249849
 * @date 2019-03-28
 */
public class GeneratorException extends RuntimeException {
    public GeneratorException(String message) {
        super(message);
    }

    public GeneratorException(String message, Throwable cause) {
        super(message, cause);
    }
}
