package com.oppo.iot.smarthome.common.utils.id.exception;

/**
 * @author 80249849
 * @date 2019-03-27
 */
public class ConfigNotFoundException extends RuntimeException {
    public ConfigNotFoundException(String message) {
        super(message);
    }

    public ConfigNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }
}
