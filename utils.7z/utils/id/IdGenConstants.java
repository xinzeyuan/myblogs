package com.oppo.iot.smarthome.common.utils.id;

/**
 * @author 80249849
 * @date 2019-03-28
 */
public interface IdGenConstants {
    int FETCHER_ERROR_CODE = -1;
    char[] DICT = new char[]{
            'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n',
            'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B',
            'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P',
            'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '0', '1', '2', '3',
            '4', '5', '6', '7', '8', '9', '-',
    };

    // =========================== env ===========================

    String IDC_KEY = "paas_idc_code";
    String APP_ID_ENV_KEY = "heracles_app_id";

    // =========================== config keys ===========================

    String CONFIG_FILE_NAME = "idconfig.properties";

    String DB_URL_CONFIG_KEY = "id.jdbc.url";
    String DB_DRIVER_CONFIG_KEY = "id.jdbc.driver";
    String DB_USERNAME_CONFIG_KEY = "id.jdbc.username";
    String DB_PASSWORD_CONFIG_KEY = "id.jdbc.password";

}
