package com.oppo.iot.smarthome.common.utils.id;

import com.oppo.basic.heracles.client.HeraclesBootstrap;
import com.oppo.basic.heracles.client.core.store.KVStore;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Properties;

/**
 * @author 80249849
 * @date 2019-03-27
 */
public abstract class AbstractVmIdFetcher {
    private static final Logger LOGGER = LoggerFactory.getLogger(AbstractVmIdFetcher.class);
    protected static final Properties PROP;
    protected static final String APP_ID;

    static {
        HeraclesBootstrap.getInstance().init("*");
        PROP = KVStore.getAllProperties().get(IdGenConstants.CONFIG_FILE_NAME);
        String appId;
        if ("dev".equals(KVStore.getStringKey("env"))) {
            LOGGER.info("===============================================================\n" +
                    "===============================================================\n" +
                    "================    ID生成器采用【本地开发模式】   ================\n" +
                    "===============================================================\n" +
                    "===============================================================");
            appId = "LOCAL-DEVELOP-APPID";
        } else {
            LOGGER.info("===============================================================\n" +
                    "===============================================================\n" +
                    "================  ID生成器采用【测试/生产环境模式】 ================\n" +
                    "===============================================================\n" +
                    "===============================================================");
            appId = System.getenv(IdGenConstants.APP_ID_ENV_KEY);
        }
        if (appId == null) {
            LOGGER.error("can not read system environment \"{}\".", IdGenConstants.APP_ID_ENV_KEY);
            System.exit(1);
        }
        APP_ID = appId;
    }

    /**
     * fetch unique id for this jvm, or `FETCHER_ERROR_CODE` if any exception occurred.
     */
    protected abstract int fetch();
}
