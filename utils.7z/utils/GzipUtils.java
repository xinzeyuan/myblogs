package com.oppo.iot.smarthome.common.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/**
 * @author 80119490
 * @Date 2018/7/11
 */
public class GzipUtils {

    private static final Logger LOGGER = LoggerFactory.getLogger(GzipUtils.class);

    public static byte[] compress(byte[] data){
        if(data == null){
            return null;
        }
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        GZIPOutputStream gzipOutputStream = null;
        try {
            gzipOutputStream = new GZIPOutputStream(outputStream);
            gzipOutputStream.write(data);
            gzipOutputStream.close();
        } catch (Exception e) {
            LOGGER.error("compress data error,",e);
        }
        finally {
            if(gzipOutputStream != null){
                try {
                    gzipOutputStream.close();
                } catch (IOException e) {
                    LOGGER.error("close gzip stream error",e);
                }
            }
        }
        return outputStream.toByteArray();
    }


    public static byte[] unCompress(byte[] data){
        if(data == null ){
            return null;
        }
        ByteArrayInputStream inputStream = new ByteArrayInputStream(data);
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        GZIPInputStream gzipInputStream = null;
        try {
            gzipInputStream = new GZIPInputStream(inputStream);
            byte[] tmpBuffer = new byte[256];
            int index = 0;
            while ((index = gzipInputStream.read(tmpBuffer)) >= 0){
                outputStream.write(tmpBuffer,0,index);
            }
        }
        catch (Exception ex){
            LOGGER.error("uncompress gzip data error",ex);
        }
        finally {
            if(gzipInputStream != null){
                try {
                    gzipInputStream.close();
                } catch (IOException e) {
                    LOGGER.error("close gzip stream error",e);
                }
            }
        }
        return outputStream.toByteArray();
    }
}
