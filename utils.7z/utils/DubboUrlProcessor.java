/*
 * Copyright (c) 2019 OPPO. All rights reserved.
 */
package com.oppo.iot.smarthome.common.utils;

import org.apache.commons.lang.ArrayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.BeanPostProcessor;

import java.io.InputStream;
import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * <p>
 * Description:
 * </p>
 *
 * @author ouyangyiding
 * @version 1.0
 * @Date 2019/5/29
 */
public class DubboUrlProcessor implements BeanPostProcessor {
    private static final Logger log = LoggerFactory.getLogger(DubboUrlProcessor.class);

    private Boolean isDev;

    private Set<String> packageNames;

    @Value("${dubbo.url}:#{null}")
    private String dubboUrl;
    @Value("${dubbo.packages:#{null}}")
    private String[] packages;

    private synchronized void init() {
        if (isDev != null) {
            return;
        }

        Properties properties = new Properties();
        try (InputStream is = this.getClass().getResourceAsStream("/heracles.properties")) {
            properties.load(is);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        String env = properties.getProperty("heracles_env", "null");

        isDev = "dev".equals(env);
        if (isDev && ArrayUtils.isNotEmpty(packages)) {
            packageNames = Stream.of(packages).collect(Collectors.toSet());
        }
    }

    @Override
    public Object postProcessBeforeInitialization(Object o, String s) throws BeansException {
        init();
        if (!isDev) {
            return o;
        }
        if (dubboUrl == null) {
            return o;
        }
        if (!packageNames.contains(o.getClass().getPackage().getName())) {
            return o;
        }

        for (Field field : o.getClass().getDeclaredFields()) {
            Annotation[] annotations = field.getAnnotations();
            if (ArrayUtils.isEmpty(annotations)) {
                continue;
            }

            for (Annotation annotation : annotations) {
                if ("com.alibaba.dubbo.config.annotation.Reference".equals(
                        annotation.annotationType().getName())) {
                    try {
                        log.info("bean:{} field:{} update-dubbo-url", s, field);
                        updateReference(annotation);
                    } catch (Exception e) {
                        log.error(e.getMessage(), e);
                    }
                    continue;
                }
            }
        }
        return o;
    }

    @Override
    public Object postProcessAfterInitialization(Object o, String s) throws BeansException {
        return o;
    }

    private void updateReference(Annotation annotation) throws Exception {
        InvocationHandler invocationHandler = Proxy.getInvocationHandler(annotation);
        Field mapField = invocationHandler.getClass().getDeclaredField("memberValues");
        mapField.setAccessible(true);
        Map memberValues = (Map) mapField.get(invocationHandler);
        memberValues.put("url", dubboUrl);
    }
}
