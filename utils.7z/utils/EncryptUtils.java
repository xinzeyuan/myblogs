package com.oppo.iot.smarthome.common.utils;

import com.oppo.iot.smarthome.common.constant.CharsetConstant;
import com.oppo.trace.core.utils.AppSecurityUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.Hex;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.security.spec.AlgorithmParameterSpec;

/**
 * @author 80249849
 * @date 2019-05-22
 */
@Slf4j
public class EncryptUtils {
    private final static String CTR = "AES/CTR/NoPadding";

    private EncryptUtils() {
    }

    private final static String AES_KEY_ENCRYPT_MOBILE = "5b6a2235f32e2680";

    public static String encryptMobile(String mobile) {
        try {
            byte[] bytes = mobile.getBytes();
            byte[] key = AES_KEY_ENCRYPT_MOBILE.getBytes();

            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
            SecretKeySpec secretKeySpec = new SecretKeySpec(key, "AES");
            cipher.init(Cipher.ENCRYPT_MODE, secretKeySpec);
            byte[] result = cipher.doFinal(bytes);

            return Hex.encodeHexString(result);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return null;
        }
    }

    public static String decryptMobile(String encryptStr, String secretKey) {
        try {
            KeyGenerator kgen = KeyGenerator.getInstance("AES");
            SecureRandom random = SecureRandom.getInstance("SHA1PRNG");
            random.setSeed(secretKey.getBytes(StandardCharsets.UTF_8));
            kgen.init(128, random);
            byte[] encoded = kgen.generateKey()
                    .getEncoded();

            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
            SecretKeySpec secretKeySpec = new SecretKeySpec(encoded, "AES");
            cipher.init(Cipher.DECRYPT_MODE, secretKeySpec);

            byte[] encryptBytes = Base64.decodeBase64(encryptStr);
            byte[] decryptBytes = cipher.doFinal(encryptBytes);
            return new String(decryptBytes);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return null;
        }
    }

    public static String decryptSsoid(String ssoid, String secretKey) {
        return new String(
                AppSecurityUtils.AES.ECB.decrypt(
                        AppSecurityUtils.hexToBin(ssoid),
                        AppSecurityUtils.hexToBin(secretKey)
                ), CharsetConstant.UTF_8);
    }

    public static String encryptSsoid(String ssoid, String secretKey) {
        return AppSecurityUtils.binToHex(
                AppSecurityUtils.AES.ECB.encrypt(
                        ssoid.getBytes(),
                        AppSecurityUtils.hexToBin(secretKey)));
    }


    public static byte[] encryptCTR(byte[] data, byte[] key, byte[] iv) {
        try {
            SecretKeySpec skeySpec = new SecretKeySpec(key, "AES");
            Cipher cipher = Cipher.getInstance(CTR);
            AlgorithmParameterSpec params = new IvParameterSpec(iv);
            cipher.init(Cipher.ENCRYPT_MODE, skeySpec, params);
            return cipher.doFinal(data);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static byte[] decryptCTR(byte[] data, byte[] key, byte[] iv) {
        try {
            SecretKeySpec skeySpec = new SecretKeySpec(key, "AES");
            Cipher cipher = Cipher.getInstance(CTR);
            AlgorithmParameterSpec params = new IvParameterSpec(iv);
            cipher.init(Cipher.DECRYPT_MODE, skeySpec, params);
            return cipher.doFinal(data);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
