package com.oppo.iot.smarthome.common.utils;

import java.util.UUID;

/**
 * Created by 80232516 on 2018/7/5.
 */
public class IdGenerator {

    public static String uuid() {
        String uuid = UUID.randomUUID().toString();
        return uuid.replaceAll("-","");
    }

}
