package com.oppo.iot.smarthome.common.utils;

import com.google.common.collect.Maps;
import com.oppo.trace.core.TraceSegment;
import com.oppo.trace.core.TraceThreadLocal;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.Map;

/**
 * @author 80119490
 */
public class HttpUtils {
	private static final Logger LOGGER = LoggerFactory.getLogger(HttpUtils.class);

	public static byte[] fetch(String url,String method, Map<String,String> header,byte[] body,Integer connectionTimeout,Integer readTimeOut) {
		String traceId = TraceThreadLocal.getTraceId();
		byte[] data = null;

		if(traceId == null){
			try {
				data =  fetchWithoutTrace(url, method, header, body, connectionTimeout, readTimeOut);
				return data;
			} catch (IOException e) {
				LOGGER.error("http fetch error,url:{}",url,e);
			}
		}

		String traceUrl = url;
		if(url.indexOf("?") > -1){
			traceUrl = url.substring(0,url.indexOf("?"));
		}
		TraceSegment segment = new TraceSegment.Builder().methodName("Call " + traceUrl).nodeType("HttpClient").build();
		try{
			if(segment.getLevel() != null){
			    if(header == null){
			        header = Maps.newHashMap();
                }
				header.put("traceId",traceId);
				header.put("level",segment.getLevel());
			}

			data = fetchWithoutTrace(url,method,header,body,connectionTimeout,readTimeOut);

			if(data == null){
				segment.statusError("fetch url failed!,url:"+url);
			}
			else {
				segment.statusOK();
			}
			return data;
		}
		catch (Exception ex){
			LOGGER.error("fetch failed! {}",ex);
            segment.statusError(ex);
		}
		return null;
	}

	private static byte[] fetchWithoutTrace(String url, String method, Map<String, String> header, byte[] body, Integer connectionTimeout, Integer readTimeOut) throws IOException {
        return ApacheHttpClient.execute(url, method, header, body, connectionTimeout, readTimeOut);
	}
}