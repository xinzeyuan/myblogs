package com.oppo.iot.smarthome.common.utils;

import com.google.common.util.concurrent.ThreadFactoryBuilder;
import com.oppo.trace.threadpool.TraceExecutorService;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * @author 80119094
 * @date 2016-12-16
 * 说明:
 */
public class ThreadPoolFactory {

    private static volatile ThreadPoolFactory ourInstance = null;

    private ExecutorService executorService;

    private static final int availableProcessors = Runtime.getRuntime().availableProcessors();

    private static int coreSize = (availableProcessors / 2) < 2 ? 2 : availableProcessors / 2;

    private static int maxPoolSize = availableProcessors * 8;

    /**
     * 4000个最多几MB
     */
    private volatile static int queueSize = 4096;

    public static void init(int core, int max, int length) {
        coreSize = core;
        maxPoolSize = max;
        queueSize = length;
    }

    private ThreadPoolFactory() {
        executorService = new TraceExecutorService(
                new ThreadPoolExecutor(coreSize, maxPoolSize, 0, TimeUnit.MILLISECONDS,
                        new LinkedBlockingQueue<>(queueSize),
                        new ThreadFactoryBuilder().build(),
                        new ThreadPoolExecutor.AbortPolicy()));
    }

    /**
     * 懒加载双锁会被 哥布伦 代码扫描报错
     * 1.7以后，方法锁性能足够强
     * @return
     */
    public static synchronized ThreadPoolFactory getInstance() {
        if (ourInstance == null) {
            ourInstance = new ThreadPoolFactory();
        }
        return ourInstance;
    }

    public ExecutorService getThreadPool() {
        return executorService;
    }

    public static void execute(Runnable runnable) {
        getInstance()
                .getThreadPool()
                .execute(runnable);
    }
}
