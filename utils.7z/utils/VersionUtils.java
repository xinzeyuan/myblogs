package com.oppo.iot.smarthome.common.utils;

import com.oppo.iot.smarthome.common.inf.Versionable;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * @author 80249849
 * @date 2019-03-29
 */
public class VersionUtils {
    private static final Comparator<String> ELEMENT_COMPARATOR = Comparator.comparing(Long::valueOf);

    public static final String SPLITTER = "\\.";
    public static final Comparator<String> VERSION_COMPARATOR = (o1, o2) -> {
        String[] arr1 = o1.split(SPLITTER);
        String[] arr2 = o2.split(SPLITTER);
        int minLen = minLen(arr1, arr2);
        for (int i = 0; i < minLen; i++) {
            int result;
            try {
                result = ELEMENT_COMPARATOR.compare(arr1[i], arr2[i]);
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException();
            }
            if (result > 0) {
                return 1;
            } else if (result < 0) {
                return -1;
            }
        }
        return lenDiff(o1, o2);
    };

    private VersionUtils() {
    }

    /**
     * 版本号排序, 形如 1.0.0
     *
     * @param list 需排序的版本号集合
     * @throws IllegalArgumentException 格式错误
     */
    public static List<String> commonVerSort(List<String> list) {
        if (CollectionUtils.isEmpty(list)) {
            return list;
        }
        return list.stream()
                .filter(Objects::nonNull)
                .sorted(VERSION_COMPARATOR)
                .collect(Collectors.toList());
    }

    /**
     * 版本号过滤
     *
     * @param list 需过滤的对象集合
     * @param ver  当前版本
     * @return getVer() 返回值小于当前版本的集合元素
     * @throws IllegalArgumentException 格式错误
     */
    public static List<Versionable> filterVer(List<? extends Versionable> list, String ver) {

        if (StringUtils.isEmpty(ver) || CollectionUtils.isEmpty(list)) {
            return new ArrayList<>();
        }
        List<Versionable> retVal = new ArrayList<>(list.size());
        list.stream()
                .filter(item -> Objects.nonNull(item) && StringUtils.isNotEmpty(item.getVer()))
                .filter(item -> VERSION_COMPARATOR.compare(ver, item.getVer()) >= 0)
                .forEach(retVal::add);
        return retVal;
    }

    private static int minLen(String[] o1, String[] o2) {
        return Math.min(o1.length, o2.length);
    }

    private static int lenDiff(String o1, String o2) {
        return Math.subtractExact(o1.length(), o2.length());
    }

}
