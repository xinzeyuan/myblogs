package com.oppo.iot.smarthome.common.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

public class BeanUtils {
    private static final Logger LOGGER = LoggerFactory.getLogger(BeanUtils.class);

    public static <T> List<T> convert(List fromValues, Class<T> toValueType) {
        List<T> instances = new ArrayList<T>();
        if (fromValues == null || fromValues.isEmpty()) {
            return instances;
        }
        fromValues.stream().forEach(fromValue -> {
            T instance = null;
            try {
                if (fromValue != null) {
                    instance = toValueType.newInstance();
                    org.springframework.beans.BeanUtils.copyProperties(fromValue,instance);
                    instances.add(instance);
                }
            } catch (Exception e) {
                LOGGER.error("convert error",e);
            }
        });
        return instances;
    }

    public static <T> T convert(Object fromValue,Class<T> toValueType) {
        T instance = null;
        try {
            instance = toValueType.newInstance();
            if (fromValue != null) {
                org.springframework.beans.BeanUtils.copyProperties(fromValue,instance);
            }
        } catch (Exception e) {
            LOGGER.error("convert error",e);
        }
        return instance;
    }

    public static <T> List<T>  convert(List fromValues, Class<T> toValueType, String... ignoreProperties) {
        List<T> instances = new ArrayList<T>();
        if (fromValues == null || fromValues.isEmpty()) {
            return instances;
        }
        fromValues.stream().forEach(fromValue -> {
            T instance = null;
            try {
                if (fromValue != null) {
                    instance = toValueType.newInstance();
                    org.springframework.beans.BeanUtils.copyProperties(fromValue, instance, ignoreProperties);
                    instances.add(instance);
                }
            } catch (Exception e) {
                LOGGER.error("convert error",e);
            }
        });
        return instances;
    }

    public static <T> T convert(Object fromValue, Class<T> toValueType, String... ignoreProperties) {
        T instance = null;
        try {
            instance = toValueType.newInstance();
            if (fromValue != null) {
                org.springframework.beans.BeanUtils.copyProperties(fromValue, instance, ignoreProperties);
            }
        } catch (Exception e) {
            LOGGER.error("convert error", e);
        }
        return instance;
    }

    public static void copyProperties(Object source, Object target) {
         org.springframework.beans.BeanUtils.copyProperties(source,target);
    }
}
