package com.oppo.iot.smarthome.common.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Created by 80188716 on 2018/6/12.
 */
public class PropertiesUtils {

    public static Properties properties;

    public static String getValue(String key){
        if(properties == null){
            InputStream inputStream = null;
            properties = new Properties();
            File propertiesFile = new File(System.getProperty("user.dir"), "conf/application.properties");
            if (!propertiesFile.exists()) {
                propertiesFile = new File(System.getProperty("user.dir"), "src/main/conf/application.properties");
            }
            try{
                inputStream = new FileInputStream(propertiesFile);
                properties = new Properties();
                properties.load(inputStream);
                return properties.getProperty(key);
            }catch (Exception e) {
                e.printStackTrace();
            }finally {
                if(inputStream != null){
                    try {
                        inputStream.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }else{
            return properties.getProperty(key);
        }
        return null;
    }

    public static String getValue(String key, String defaultValue){
        if(getValue(key) != null){
            return getValue(key);
        }
        return defaultValue;
    }

}
