package com.oppo.iot.smarthome.common.utils;

/**
 * @author 80249849
 * @date 2019-11-25
 */
public class LockKeyUtils {
    private LockKeyUtils() {
    }

    public static String getInstanceLockKey(String ssoid, String deviceId) {
        return "LOCK:INSTANCE:" + ssoid + ":" + deviceId;
    }

    public static String getHomeLockKey(String ssoid) {
        return "LOCK:HOME:" + ssoid;
    }
}
